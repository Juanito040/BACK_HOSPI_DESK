export { ITicketRepository, TicketFilters } from './ITicketRepository';
export { IUserRepository } from './IUserRepository';
export { IAreaRepository } from './IAreaRepository';
export { ICommentRepository } from './ICommentRepository';
export { IAttachmentRepository } from './IAttachmentRepository';
export { ISLARepository } from './ISLARepository';
export { IAuditTrailRepository } from './IAuditTrailRepository';
